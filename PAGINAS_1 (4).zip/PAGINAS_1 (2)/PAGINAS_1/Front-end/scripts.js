let currentPage = 1;
const rowsPerPage = 10;
let totalBooks = 0;

document.addEventListener("DOMContentLoaded", function() {
    fetchTotalBooks().then(() => loadPage(currentPage));

    document.getElementById('first-page').addEventListener('click', () => {
        currentPage = 1;
        loadPage(currentPage);
    });

    document.getElementById('prev-page').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            loadPage(currentPage);
        }
    });

    document.getElementById('next-page').addEventListener('click', () => {
        if (currentPage < Math.ceil(totalBooks / rowsPerPage)) {
            currentPage++;
            loadPage(currentPage);
        }
    });

    document.getElementById('last-page').addEventListener('click', () => {
        currentPage = Math.ceil(totalBooks / rowsPerPage);
        loadPage(currentPage);
    });
});

async function fetchTotalBooks() {
    try {
        const response = await fetch(`http://localhost:3008/len`);
        const len = await response.json();
        totalBooks = len;
        updateTotalBooksInfo();
        createPageButtons();
        updateNavigationButtons();
    } catch (error) {
        console.error("Erro ao buscar o total de livros:", error);
    }
}

async function loadPage(page) {
    try {
        const response = await fetch(`http://localhost:3008/livros/${page}`);
        const books = await response.json();
        renderBooks(books);
        updateTotalBooksInfo();
        createPageButtons();
        updateNavigationButtons();
    } catch (error) {
        console.error("Erro ao carregar os livros:", error);
    }
}

function updateTotalBooksInfo() {
    document.getElementById('total-books').innerText = `Exibindo de ${(currentPage - 1) * rowsPerPage + 1} até ${Math.min(currentPage * rowsPerPage, totalBooks)} de ${totalBooks} livros`;
}

function renderBooks(books) {
    const table = document.getElementById('book-table');
    table.innerHTML = '';

    books.forEach(book => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${book.titulo}</td>
            <td>${book.autor}</td>
            <td>${book.isbn}</td>
            <td>${book.paginas}</td>
            <td>${book.ano}</td>
            <td>R$${book.valor}</td>
        `;
        table.appendChild(row);
    });
}

function createPageButtons() {
    const pageButtonsContainer = document.getElementById('page-buttons');
    pageButtonsContainer.innerHTML = '';

    const totalPages = Math.ceil(totalBooks / rowsPerPage);
    const startPage = Math.max(currentPage - 3, 1);
    const endPage = Math.min(currentPage + 3, totalPages);

    for (let i = startPage; i <= endPage; i++) {
        const button = document.createElement('button');
        button.innerText = i;
        button.classList.add('page-button');
        if (i === currentPage) {
            button.classList.add('active');
        } else {
            button.addEventListener('click', () => {
                currentPage = i;
                loadPage(currentPage);
            });
        }
        pageButtonsContainer.appendChild(button);
    }
}

function updateNavigationButtons() {
    const totalPages = Math.ceil(totalBooks / rowsPerPage);

    const firstPageButton = document.getElementById('first-page');
    const prevPageButton = document.getElementById('prev-page');
    const nextPageButton = document.getElementById('next-page');
    const lastPageButton = document.getElementById('last-page');

    firstPageButton.disabled = currentPage === 1;
    prevPageButton.disabled = currentPage === 1;
    nextPageButton.disabled = currentPage === totalPages;
    lastPageButton.disabled = currentPage === totalPages;
}
