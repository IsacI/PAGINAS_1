const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const port = process.env.PORT || 3008;
const uri = process.env.MONGODB_URI || "mongodb://localhost:27017";
const dbName = 'livros';
const collectionName = 'livro';


app.use(cors());
app.use(express.json());

app.get(`/livros/:page`, async (req, res) => {
    try {
        const page = parseInt(req.params.page);
        const skip = (page - 1) * 10;
        const books = await connectAndFindWithPagination(skip);
        res.json(books);
    } catch (error) {
        console.log("Algo deu errado: ", error);
        res.status(500).json({ error: "Deu erro no sever_:(" });
    }
});

app.get(`/len`, async (req, res) => {
    try {
        const amount = await len();
        res.json(amount);
    } catch (error) {
        console.log("OPS DEU ERRADO: ", error);
        res.status(500).json({ error: "INTERN ERROR SEVER" });
    }
});

async function connectAndFindWithPagination(skip) {
    const client = new MongoClient(uri);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(collectionName);
        const result = await collection.find({}).skip(skip).limit(10).toArray();
        return result;
    } finally {
        await client.close();
    }
}

async function len() {
    const client = new MongoClient(uri);
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(collectionName);
        const result = await collection.find({}).count();
        return result;
    } finally {
        await client.close();
    }
}

app.listen(port, () => {
    console.log(`Server is running in port ${port}`);
});
